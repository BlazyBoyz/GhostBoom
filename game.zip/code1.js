gdjs.Untitled_32sceneCode = {};
gdjs.Untitled_32sceneCode.GDCenterObjects1_1final = [];

gdjs.Untitled_32sceneCode.GDEnemyBulletObjects1_1final = [];

gdjs.Untitled_32sceneCode.GDGhostEnemyObjects1_1final = [];

gdjs.Untitled_32sceneCode.GDImpEnemyObjects1_1final = [];

gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects1_1final = [];

gdjs.Untitled_32sceneCode.forEachCount0_3 = 0;

gdjs.Untitled_32sceneCode.forEachCount1_3 = 0;

gdjs.Untitled_32sceneCode.forEachCount2_3 = 0;

gdjs.Untitled_32sceneCode.forEachIndex3 = 0;

gdjs.Untitled_32sceneCode.forEachObjects3 = [];

gdjs.Untitled_32sceneCode.forEachTotalCount3 = 0;

gdjs.Untitled_32sceneCode.GDFloorObjects1= [];
gdjs.Untitled_32sceneCode.GDFloorObjects2= [];
gdjs.Untitled_32sceneCode.GDFloorObjects3= [];
gdjs.Untitled_32sceneCode.GDFloorObjects4= [];
gdjs.Untitled_32sceneCode.GDFloorObjects5= [];
gdjs.Untitled_32sceneCode.GDPlayerObjects1= [];
gdjs.Untitled_32sceneCode.GDPlayerObjects2= [];
gdjs.Untitled_32sceneCode.GDPlayerObjects3= [];
gdjs.Untitled_32sceneCode.GDPlayerObjects4= [];
gdjs.Untitled_32sceneCode.GDPlayerObjects5= [];
gdjs.Untitled_32sceneCode.GDGunObjects1= [];
gdjs.Untitled_32sceneCode.GDGunObjects2= [];
gdjs.Untitled_32sceneCode.GDGunObjects3= [];
gdjs.Untitled_32sceneCode.GDGunObjects4= [];
gdjs.Untitled_32sceneCode.GDGunObjects5= [];
gdjs.Untitled_32sceneCode.GDBulletObjects1= [];
gdjs.Untitled_32sceneCode.GDBulletObjects2= [];
gdjs.Untitled_32sceneCode.GDBulletObjects3= [];
gdjs.Untitled_32sceneCode.GDBulletObjects4= [];
gdjs.Untitled_32sceneCode.GDBulletObjects5= [];
gdjs.Untitled_32sceneCode.GDGhostEnemyObjects1= [];
gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2= [];
gdjs.Untitled_32sceneCode.GDGhostEnemyObjects3= [];
gdjs.Untitled_32sceneCode.GDGhostEnemyObjects4= [];
gdjs.Untitled_32sceneCode.GDGhostEnemyObjects5= [];
gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects1= [];
gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2= [];
gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects3= [];
gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects4= [];
gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects5= [];
gdjs.Untitled_32sceneCode.GDImpEnemyObjects1= [];
gdjs.Untitled_32sceneCode.GDImpEnemyObjects2= [];
gdjs.Untitled_32sceneCode.GDImpEnemyObjects3= [];
gdjs.Untitled_32sceneCode.GDImpEnemyObjects4= [];
gdjs.Untitled_32sceneCode.GDImpEnemyObjects5= [];
gdjs.Untitled_32sceneCode.GDCenterObjects1= [];
gdjs.Untitled_32sceneCode.GDCenterObjects2= [];
gdjs.Untitled_32sceneCode.GDCenterObjects3= [];
gdjs.Untitled_32sceneCode.GDCenterObjects4= [];
gdjs.Untitled_32sceneCode.GDCenterObjects5= [];
gdjs.Untitled_32sceneCode.GDSpawnPointsObjects1= [];
gdjs.Untitled_32sceneCode.GDSpawnPointsObjects2= [];
gdjs.Untitled_32sceneCode.GDSpawnPointsObjects3= [];
gdjs.Untitled_32sceneCode.GDSpawnPointsObjects4= [];
gdjs.Untitled_32sceneCode.GDSpawnPointsObjects5= [];
gdjs.Untitled_32sceneCode.GDSpiderSpawnPointsObjects1= [];
gdjs.Untitled_32sceneCode.GDSpiderSpawnPointsObjects2= [];
gdjs.Untitled_32sceneCode.GDSpiderSpawnPointsObjects3= [];
gdjs.Untitled_32sceneCode.GDSpiderSpawnPointsObjects4= [];
gdjs.Untitled_32sceneCode.GDSpiderSpawnPointsObjects5= [];
gdjs.Untitled_32sceneCode.GDHealthBar_9595EnemyObjects1= [];
gdjs.Untitled_32sceneCode.GDHealthBar_9595EnemyObjects2= [];
gdjs.Untitled_32sceneCode.GDHealthBar_9595EnemyObjects3= [];
gdjs.Untitled_32sceneCode.GDHealthBar_9595EnemyObjects4= [];
gdjs.Untitled_32sceneCode.GDHealthBar_9595EnemyObjects5= [];
gdjs.Untitled_32sceneCode.GDWallCollisionObjects1= [];
gdjs.Untitled_32sceneCode.GDWallCollisionObjects2= [];
gdjs.Untitled_32sceneCode.GDWallCollisionObjects3= [];
gdjs.Untitled_32sceneCode.GDWallCollisionObjects4= [];
gdjs.Untitled_32sceneCode.GDWallCollisionObjects5= [];
gdjs.Untitled_32sceneCode.GDvignetteObjects1= [];
gdjs.Untitled_32sceneCode.GDvignetteObjects2= [];
gdjs.Untitled_32sceneCode.GDvignetteObjects3= [];
gdjs.Untitled_32sceneCode.GDvignetteObjects4= [];
gdjs.Untitled_32sceneCode.GDvignetteObjects5= [];
gdjs.Untitled_32sceneCode.GDRedFlatBarObjects1= [];
gdjs.Untitled_32sceneCode.GDRedFlatBarObjects2= [];
gdjs.Untitled_32sceneCode.GDRedFlatBarObjects3= [];
gdjs.Untitled_32sceneCode.GDRedFlatBarObjects4= [];
gdjs.Untitled_32sceneCode.GDRedFlatBarObjects5= [];
gdjs.Untitled_32sceneCode.GDEXP_9595PointObjects1= [];
gdjs.Untitled_32sceneCode.GDEXP_9595PointObjects2= [];
gdjs.Untitled_32sceneCode.GDEXP_9595PointObjects3= [];
gdjs.Untitled_32sceneCode.GDEXP_9595PointObjects4= [];
gdjs.Untitled_32sceneCode.GDEXP_9595PointObjects5= [];
gdjs.Untitled_32sceneCode.GDStatsObjects1= [];
gdjs.Untitled_32sceneCode.GDStatsObjects2= [];
gdjs.Untitled_32sceneCode.GDStatsObjects3= [];
gdjs.Untitled_32sceneCode.GDStatsObjects4= [];
gdjs.Untitled_32sceneCode.GDStatsObjects5= [];
gdjs.Untitled_32sceneCode.GDPowerButtonObjects1= [];
gdjs.Untitled_32sceneCode.GDPowerButtonObjects2= [];
gdjs.Untitled_32sceneCode.GDPowerButtonObjects3= [];
gdjs.Untitled_32sceneCode.GDPowerButtonObjects4= [];
gdjs.Untitled_32sceneCode.GDPowerButtonObjects5= [];
gdjs.Untitled_32sceneCode.GDFireRateButtonObjects1= [];
gdjs.Untitled_32sceneCode.GDFireRateButtonObjects2= [];
gdjs.Untitled_32sceneCode.GDFireRateButtonObjects3= [];
gdjs.Untitled_32sceneCode.GDFireRateButtonObjects4= [];
gdjs.Untitled_32sceneCode.GDFireRateButtonObjects5= [];
gdjs.Untitled_32sceneCode.GDAccuracyButtonObjects1= [];
gdjs.Untitled_32sceneCode.GDAccuracyButtonObjects2= [];
gdjs.Untitled_32sceneCode.GDAccuracyButtonObjects3= [];
gdjs.Untitled_32sceneCode.GDAccuracyButtonObjects4= [];
gdjs.Untitled_32sceneCode.GDAccuracyButtonObjects5= [];
gdjs.Untitled_32sceneCode.GDWaveNumberObjects1= [];
gdjs.Untitled_32sceneCode.GDWaveNumberObjects2= [];
gdjs.Untitled_32sceneCode.GDWaveNumberObjects3= [];
gdjs.Untitled_32sceneCode.GDWaveNumberObjects4= [];
gdjs.Untitled_32sceneCode.GDWaveNumberObjects5= [];
gdjs.Untitled_32sceneCode.GDEnemyBulletObjects1= [];
gdjs.Untitled_32sceneCode.GDEnemyBulletObjects2= [];
gdjs.Untitled_32sceneCode.GDEnemyBulletObjects3= [];
gdjs.Untitled_32sceneCode.GDEnemyBulletObjects4= [];
gdjs.Untitled_32sceneCode.GDEnemyBulletObjects5= [];
gdjs.Untitled_32sceneCode.GDShadowObjects1= [];
gdjs.Untitled_32sceneCode.GDShadowObjects2= [];
gdjs.Untitled_32sceneCode.GDShadowObjects3= [];
gdjs.Untitled_32sceneCode.GDShadowObjects4= [];
gdjs.Untitled_32sceneCode.GDShadowObjects5= [];
gdjs.Untitled_32sceneCode.GDDropObjects1= [];
gdjs.Untitled_32sceneCode.GDDropObjects2= [];
gdjs.Untitled_32sceneCode.GDDropObjects3= [];
gdjs.Untitled_32sceneCode.GDDropObjects4= [];
gdjs.Untitled_32sceneCode.GDDropObjects5= [];
gdjs.Untitled_32sceneCode.GDMovementObjects1= [];
gdjs.Untitled_32sceneCode.GDMovementObjects2= [];
gdjs.Untitled_32sceneCode.GDMovementObjects3= [];
gdjs.Untitled_32sceneCode.GDMovementObjects4= [];
gdjs.Untitled_32sceneCode.GDMovementObjects5= [];
gdjs.Untitled_32sceneCode.GDAimingObjects1= [];
gdjs.Untitled_32sceneCode.GDAimingObjects2= [];
gdjs.Untitled_32sceneCode.GDAimingObjects3= [];
gdjs.Untitled_32sceneCode.GDAimingObjects4= [];
gdjs.Untitled_32sceneCode.GDAimingObjects5= [];
gdjs.Untitled_32sceneCode.GDTransitionObjects1= [];
gdjs.Untitled_32sceneCode.GDTransitionObjects2= [];
gdjs.Untitled_32sceneCode.GDTransitionObjects3= [];
gdjs.Untitled_32sceneCode.GDTransitionObjects4= [];
gdjs.Untitled_32sceneCode.GDTransitionObjects5= [];
gdjs.Untitled_32sceneCode.GDDarkenObjects1= [];
gdjs.Untitled_32sceneCode.GDDarkenObjects2= [];
gdjs.Untitled_32sceneCode.GDDarkenObjects3= [];
gdjs.Untitled_32sceneCode.GDDarkenObjects4= [];
gdjs.Untitled_32sceneCode.GDDarkenObjects5= [];


gdjs.Untitled_32sceneCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.isMobile());
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Aiming"), gdjs.Untitled_32sceneCode.GDAimingObjects1);
gdjs.copyArray(runtimeScene.getObjects("Movement"), gdjs.Untitled_32sceneCode.GDMovementObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDMovementObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDMovementObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDAimingObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDAimingObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Untitled_32sceneCode.eventsList1 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Floor"), gdjs.Untitled_32sceneCode.GDFloorObjects1);
gdjs.copyArray(runtimeScene.getObjects("SpiderSpawnPoints"), gdjs.Untitled_32sceneCode.GDSpiderSpawnPointsObjects1);
gdjs.copyArray(runtimeScene.getObjects("Transition"), gdjs.Untitled_32sceneCode.GDTransitionObjects1);
gdjs.copyArray(runtimeScene.getObjects("WallCollision"), gdjs.Untitled_32sceneCode.GDWallCollisionObjects1);
gdjs.copyArray(runtimeScene.getObjects("vignette"), gdjs.Untitled_32sceneCode.GDvignetteObjects1);
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2, "", 0);
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2, "Vignette", 0);
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Untitled_32sceneCode.GDFloorObjects1.length !== 0 ? gdjs.Untitled_32sceneCode.GDFloorObjects1[0] : null), true, "", 0);
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Untitled_32sceneCode.GDvignetteObjects1.length !== 0 ? gdjs.Untitled_32sceneCode.GDvignetteObjects1[0] : null), true, "Vignette", 0);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDWallCollisionObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDWallCollisionObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDSpiderSpawnPointsObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDSpiderSpawnPointsObjects1[i].hide();
}
}{gdjs.evtsExt__CameraShake__SetLayerRotationAmplitude.func(runtimeScene, 1, "", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__CameraShake__SetDefaultZoomAmplitude.func(runtimeScene, 1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__CameraShake__SetLayerTranslationAmplitude.func(runtimeScene, 1, 1, "", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__CameraShake__SetLayerShakingFrequency.func(runtimeScene, 5, "", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 1.5, "transition", 0);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDTransitionObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDTransitionObjects1[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 1, "Circular", "Backward", 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.Untitled_32sceneCode.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDGhostEnemyObjects1Objects = Hashtable.newFrom({"GhostEnemy": gdjs.Untitled_32sceneCode.GDGhostEnemyObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDSpiderEnemyObjects1Objects = Hashtable.newFrom({"SpiderEnemy": gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDImpEnemyObjects1Objects = Hashtable.newFrom({"ImpEnemy": gdjs.Untitled_32sceneCode.GDImpEnemyObjects1});
gdjs.Untitled_32sceneCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Untitled_32sceneCode.GDBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("GhostEnemy"), gdjs.Untitled_32sceneCode.GDGhostEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.Untitled_32sceneCode.GDGunObjects1);
gdjs.copyArray(runtimeScene.getObjects("ImpEnemy"), gdjs.Untitled_32sceneCode.GDImpEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("SpiderEnemy"), gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayerObjects1[i].setZOrder((gdjs.Untitled_32sceneCode.GDPlayerObjects1[i].getPointY("")));
}
for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBulletObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBulletObjects1[i].setZOrder((gdjs.Untitled_32sceneCode.GDBulletObjects1[i].getPointY("")));
}
for(var i = 0, len = gdjs.Untitled_32sceneCode.GDGhostEnemyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDGhostEnemyObjects1[i].setZOrder((gdjs.Untitled_32sceneCode.GDGhostEnemyObjects1[i].getPointY("")));
}
for(var i = 0, len = gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects1[i].setZOrder((gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects1[i].getPointY("")));
}
for(var i = 0, len = gdjs.Untitled_32sceneCode.GDImpEnemyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDImpEnemyObjects1[i].setZOrder((gdjs.Untitled_32sceneCode.GDImpEnemyObjects1[i].getPointY("")));
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDGunObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDGunObjects1[i].setZOrder((( gdjs.Untitled_32sceneCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDPlayerObjects1[0].getZOrder()) + 1);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDGhostEnemyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDGhostEnemyObjects1[i].separateFromObjectsList(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDGhostEnemyObjects1Objects, false);
}
for(var i = 0, len = gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects1[i].separateFromObjectsList(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDSpiderEnemyObjects1Objects, false);
}
for(var i = 0, len = gdjs.Untitled_32sceneCode.GDImpEnemyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDImpEnemyObjects1[i].separateFromObjectsList(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDImpEnemyObjects1Objects, false);
}
}}

}


};gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDCenterObjects2Objects = Hashtable.newFrom({"Center": gdjs.Untitled_32sceneCode.GDCenterObjects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDEnemyBulletObjects2Objects = Hashtable.newFrom({"EnemyBullet": gdjs.Untitled_32sceneCode.GDEnemyBulletObjects2});
gdjs.Untitled_32sceneCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.Untitled_32sceneCode.GDCenterObjects2 */
gdjs.copyArray(runtimeScene.getObjects("EnemyBullet"), gdjs.Untitled_32sceneCode.GDEnemyBulletObjects2);
/* Reuse gdjs.Untitled_32sceneCode.GDImpEnemyObjects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDImpEnemyObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDImpEnemyObjects2[i].getBehavior("FireBullet").FireTowardPosition((gdjs.Untitled_32sceneCode.GDImpEnemyObjects2[i].getCenterXInScene()), (gdjs.Untitled_32sceneCode.GDImpEnemyObjects2[i].getCenterYInScene()), gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDEnemyBulletObjects2Objects, (( gdjs.Untitled_32sceneCode.GDCenterObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDCenterObjects2[0].getCenterXInScene()), (( gdjs.Untitled_32sceneCode.GDCenterObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDCenterObjects2[0].getCenterYInScene()), 35, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDCenterObjects2Objects = Hashtable.newFrom({"Center": gdjs.Untitled_32sceneCode.GDCenterObjects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Untitled_32sceneCode.GDPlayerObjects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDSpawnPointsObjects2Objects = Hashtable.newFrom({"SpawnPoints": gdjs.Untitled_32sceneCode.GDSpawnPointsObjects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDSpiderSpawnPointsObjects3Objects = Hashtable.newFrom({"SpiderSpawnPoints": gdjs.Untitled_32sceneCode.GDSpiderSpawnPointsObjects3});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDShadowObjects3Objects = Hashtable.newFrom({"Shadow": gdjs.Untitled_32sceneCode.GDShadowObjects3});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDDropObjects3Objects = Hashtable.newFrom({"Drop": gdjs.Untitled_32sceneCode.GDDropObjects3});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDSpiderEnemyObjects4Objects = Hashtable.newFrom({"SpiderEnemy": gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects4});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDHealthBar_95959595EnemyObjects4Objects = Hashtable.newFrom({"HealthBar_Enemy": gdjs.Untitled_32sceneCode.GDHealthBar_9595EnemyObjects4});
gdjs.Untitled_32sceneCode.asyncCallback16387044 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("SpiderSpawnPoints"), gdjs.Untitled_32sceneCode.GDSpiderSpawnPointsObjects4);

gdjs.Untitled_32sceneCode.GDHealthBar_9595EnemyObjects4.length = 0;

gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDSpiderEnemyObjects4Objects, (( gdjs.Untitled_32sceneCode.GDSpiderSpawnPointsObjects4.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDSpiderSpawnPointsObjects4[0].getPointX("")), (( gdjs.Untitled_32sceneCode.GDSpiderSpawnPointsObjects4.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDSpiderSpawnPointsObjects4[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects4.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects4[i].getBehavior("Health").SetMaxHealthOp(2 + Math.floor(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) / 3), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects4.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects4[i].getBehavior("Health").SetHealth((gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects4[i].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDHealthBar_95959595EnemyObjects4Objects, (( gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects4.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects4[0].getPointX("")), (( gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects4.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects4[0].getPointY("")), "");
}{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.Untitled_32sceneCode.GDHealthBar_9595EnemyObjects4.length !== 0 ? gdjs.Untitled_32sceneCode.GDHealthBar_9595EnemyObjects4[0] : null), (gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects4.length !== 0 ? gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects4[0] : null));
}}
gdjs.Untitled_32sceneCode.eventsList4 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Untitled_32sceneCode.GDSpiderSpawnPointsObjects3) asyncObjectsList.addObject("SpiderSpawnPoints", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Untitled_32sceneCode.asyncCallback16387044(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDGhostEnemyObjects3Objects = Hashtable.newFrom({"GhostEnemy": gdjs.Untitled_32sceneCode.GDGhostEnemyObjects3});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDHealthBar_95959595EnemyObjects3Objects = Hashtable.newFrom({"HealthBar_Enemy": gdjs.Untitled_32sceneCode.GDHealthBar_9595EnemyObjects3});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDImpEnemyObjects3Objects = Hashtable.newFrom({"ImpEnemy": gdjs.Untitled_32sceneCode.GDImpEnemyObjects3});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDHealthBar_95959595EnemyObjects3Objects = Hashtable.newFrom({"HealthBar_Enemy": gdjs.Untitled_32sceneCode.GDHealthBar_9595EnemyObjects3});
gdjs.Untitled_32sceneCode.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("SpiderSpawnPoints"), gdjs.Untitled_32sceneCode.GDSpiderSpawnPointsObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickRandomObject((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDSpiderSpawnPointsObjects3Objects);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDSpiderSpawnPointsObjects3 */
gdjs.Untitled_32sceneCode.GDDropObjects3.length = 0;

gdjs.Untitled_32sceneCode.GDShadowObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDShadowObjects3Objects, (( gdjs.Untitled_32sceneCode.GDSpiderSpawnPointsObjects3.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDSpiderSpawnPointsObjects3[0].getPointX("")), (( gdjs.Untitled_32sceneCode.GDSpiderSpawnPointsObjects3.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDSpiderSpawnPointsObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDShadowObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDShadowObjects3[i].setScale(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDShadowObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDShadowObjects3[i].getBehavior("Tween").addObjectScaleTween("Grow", 1, 1, "linear", 1000, true, false);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDDropObjects3Objects, (( gdjs.Untitled_32sceneCode.GDSpiderSpawnPointsObjects3.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDSpiderSpawnPointsObjects3[0].getPointX("")), (( gdjs.Untitled_32sceneCode.GDSpiderSpawnPointsObjects3.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDSpiderSpawnPointsObjects3[0].getPointY("")) - 100, "");
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDDropObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDDropObjects3[i].getBehavior("Tween").addObjectPositionYTween("Drop", (gdjs.Untitled_32sceneCode.GDDropObjects3[i].getPointY("")) + 100, "linear", 1000, true);
}
}
{ //Subevents
gdjs.Untitled_32sceneCode.eventsList4(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 1;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDSpawnPointsObjects2, gdjs.Untitled_32sceneCode.GDSpawnPointsObjects3);

gdjs.Untitled_32sceneCode.GDGhostEnemyObjects3.length = 0;

gdjs.Untitled_32sceneCode.GDHealthBar_9595EnemyObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDGhostEnemyObjects3Objects, (( gdjs.Untitled_32sceneCode.GDSpawnPointsObjects3.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDSpawnPointsObjects3[0].getPointX("")), (( gdjs.Untitled_32sceneCode.GDSpawnPointsObjects3.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDSpawnPointsObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDGhostEnemyObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDGhostEnemyObjects3[i].getBehavior("Health").SetMaxHealthOp(3 + Math.floor(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) / 3), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDGhostEnemyObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDGhostEnemyObjects3[i].getBehavior("Health").SetHealth((gdjs.Untitled_32sceneCode.GDGhostEnemyObjects3[i].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDHealthBar_95959595EnemyObjects3Objects, (( gdjs.Untitled_32sceneCode.GDGhostEnemyObjects3.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDGhostEnemyObjects3[0].getPointX("")), (( gdjs.Untitled_32sceneCode.GDGhostEnemyObjects3.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDGhostEnemyObjects3[0].getPointY("")), "");
}{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.Untitled_32sceneCode.GDHealthBar_9595EnemyObjects3.length !== 0 ? gdjs.Untitled_32sceneCode.GDHealthBar_9595EnemyObjects3[0] : null), (gdjs.Untitled_32sceneCode.GDGhostEnemyObjects3.length !== 0 ? gdjs.Untitled_32sceneCode.GDGhostEnemyObjects3[0] : null));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 2;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDSpawnPointsObjects2, gdjs.Untitled_32sceneCode.GDSpawnPointsObjects3);

gdjs.Untitled_32sceneCode.GDHealthBar_9595EnemyObjects3.length = 0;

gdjs.Untitled_32sceneCode.GDImpEnemyObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDImpEnemyObjects3Objects, (( gdjs.Untitled_32sceneCode.GDSpawnPointsObjects3.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDSpawnPointsObjects3[0].getPointX("")), (( gdjs.Untitled_32sceneCode.GDSpawnPointsObjects3.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDSpawnPointsObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDImpEnemyObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDImpEnemyObjects3[i].getBehavior("Health").SetMaxHealthOp(4 + Math.floor(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) / 3), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDImpEnemyObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDImpEnemyObjects3[i].getBehavior("Health").SetHealth((gdjs.Untitled_32sceneCode.GDImpEnemyObjects3[i].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDHealthBar_95959595EnemyObjects3Objects, (( gdjs.Untitled_32sceneCode.GDImpEnemyObjects3.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDImpEnemyObjects3[0].getPointX("")), (( gdjs.Untitled_32sceneCode.GDImpEnemyObjects3.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDImpEnemyObjects3[0].getPointY("")), "");
}{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.Untitled_32sceneCode.GDHealthBar_9595EnemyObjects3.length !== 0 ? gdjs.Untitled_32sceneCode.GDHealthBar_9595EnemyObjects3[0] : null), (gdjs.Untitled_32sceneCode.GDImpEnemyObjects3.length !== 0 ? gdjs.Untitled_32sceneCode.GDImpEnemyObjects3[0] : null));
}}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Enemy Spawn");
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(gdjs.randomInRange(0, Math.min(Math.floor(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) / 3), 2)));
}}

}


};gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDHealthBar_95959595EnemyObjects3Objects = Hashtable.newFrom({"HealthBar_Enemy": gdjs.Untitled_32sceneCode.GDHealthBar_9595EnemyObjects3});
gdjs.Untitled_32sceneCode.eventsList6 = function(runtimeScene) {

};gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.Untitled_32sceneCode.GDBulletObjects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDGhostEnemyObjects2ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDSpiderEnemyObjects2ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDImpEnemyObjects2Objects = Hashtable.newFrom({"GhostEnemy": gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2, "SpiderEnemy": gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2, "ImpEnemy": gdjs.Untitled_32sceneCode.GDImpEnemyObjects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDHealthBar_95959595EnemyObjects2Objects = Hashtable.newFrom({"HealthBar_Enemy": gdjs.Untitled_32sceneCode.GDHealthBar_9595EnemyObjects2});
gdjs.Untitled_32sceneCode.eventsList7 = function(runtimeScene) {

{

/* Reuse gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2 */
gdjs.copyArray(runtimeScene.getObjects("HealthBar_Enemy"), gdjs.Untitled_32sceneCode.GDHealthBar_9595EnemyObjects2);
/* Reuse gdjs.Untitled_32sceneCode.GDImpEnemyObjects2 */
/* Reuse gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDHealthBar_95959595EnemyObjects2Objects, (gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2.length !== 0 ? gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2[0] : (gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2.length !== 0 ? gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2[0] : (gdjs.Untitled_32sceneCode.GDImpEnemyObjects2.length !== 0 ? gdjs.Untitled_32sceneCode.GDImpEnemyObjects2[0] : null))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2 */
/* Reuse gdjs.Untitled_32sceneCode.GDHealthBar_9595EnemyObjects2 */
/* Reuse gdjs.Untitled_32sceneCode.GDImpEnemyObjects2 */
/* Reuse gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDHealthBar_9595EnemyObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDHealthBar_9595EnemyObjects2[i].setWidth(((( gdjs.Untitled_32sceneCode.GDImpEnemyObjects2.length === 0 ) ? (( gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2.length === 0 ) ? (( gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) :gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) :gdjs.Untitled_32sceneCode.GDImpEnemyObjects2[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) / (( gdjs.Untitled_32sceneCode.GDImpEnemyObjects2.length === 0 ) ? (( gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2.length === 0 ) ? (( gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2[0].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) :gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2[0].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) :gdjs.Untitled_32sceneCode.GDImpEnemyObjects2[0].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)))) * 12);
}
}}

}


};gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDHealthBar_95959595EnemyObjects2Objects = Hashtable.newFrom({"HealthBar_Enemy": gdjs.Untitled_32sceneCode.GDHealthBar_9595EnemyObjects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDEXP_95959595PointObjects1Objects = Hashtable.newFrom({"EXP_Point": gdjs.Untitled_32sceneCode.GDEXP_9595PointObjects1});
gdjs.Untitled_32sceneCode.eventsList8 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Untitled_32sceneCode.GDGhostEnemyObjects1, gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2);

gdjs.copyArray(runtimeScene.getObjects("HealthBar_Enemy"), gdjs.Untitled_32sceneCode.GDHealthBar_9595EnemyObjects2);
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDImpEnemyObjects1, gdjs.Untitled_32sceneCode.GDImpEnemyObjects2);

gdjs.copyArray(gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects1, gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDHealthBar_95959595EnemyObjects2Objects, (gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2.length !== 0 ? gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2[0] : (gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2.length !== 0 ? gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2[0] : (gdjs.Untitled_32sceneCode.GDImpEnemyObjects2.length !== 0 ? gdjs.Untitled_32sceneCode.GDImpEnemyObjects2[0] : null))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDHealthBar_9595EnemyObjects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDHealthBar_9595EnemyObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDHealthBar_9595EnemyObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.Untitled_32sceneCode.GDGhostEnemyObjects1 */
/* Reuse gdjs.Untitled_32sceneCode.GDImpEnemyObjects1 */
/* Reuse gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects1 */
gdjs.Untitled_32sceneCode.GDEXP_9595PointObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDEXP_95959595PointObjects1Objects, (( gdjs.Untitled_32sceneCode.GDImpEnemyObjects1.length === 0 ) ? (( gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects1.length === 0 ) ? (( gdjs.Untitled_32sceneCode.GDGhostEnemyObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDGhostEnemyObjects1[0].getPointX("")) :gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects1[0].getPointX("")) :gdjs.Untitled_32sceneCode.GDImpEnemyObjects1[0].getPointX("")), (( gdjs.Untitled_32sceneCode.GDImpEnemyObjects1.length === 0 ) ? (( gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects1.length === 0 ) ? (( gdjs.Untitled_32sceneCode.GDGhostEnemyObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDGhostEnemyObjects1[0].getPointY("")) :gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects1[0].getPointY("")) :gdjs.Untitled_32sceneCode.GDImpEnemyObjects1[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDGhostEnemyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDGhostEnemyObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Untitled_32sceneCode.GDImpEnemyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDImpEnemyObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Untitled_32sceneCode.eventsList9 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Enemy Spawn");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Wave");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Wave") > 30;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("WaveNumber"), gdjs.Untitled_32sceneCode.GDWaveNumberObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(1).add(1);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDWaveNumberObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDWaveNumberObjects2[i].setString("Wave: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1))));
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Wave");
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("ImpEnemy"), gdjs.Untitled_32sceneCode.GDImpEnemyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDImpEnemyObjects2.length;i<l;++i) {
    if ( !(gdjs.Untitled_32sceneCode.GDImpEnemyObjects2[i].isCurrentAnimationName("Hurt")) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDImpEnemyObjects2[k] = gdjs.Untitled_32sceneCode.GDImpEnemyObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDImpEnemyObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Center"), gdjs.Untitled_32sceneCode.GDCenterObjects2);
/* Reuse gdjs.Untitled_32sceneCode.GDImpEnemyObjects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDImpEnemyObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDImpEnemyObjects2[i].getBehavior("BoidsMovement").MoveToObject(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDCenterObjects2Objects, 0.5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.Untitled_32sceneCode.eventsList3(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("SpiderEnemy"), gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2.length;i<l;++i) {
    if ( !(gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2[i].isCurrentAnimationName("Hurt")) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2[k] = gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Center"), gdjs.Untitled_32sceneCode.GDCenterObjects2);
/* Reuse gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2[i].addForceTowardObject((gdjs.Untitled_32sceneCode.GDCenterObjects2.length !== 0 ? gdjs.Untitled_32sceneCode.GDCenterObjects2[0] : null), 15, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GhostEnemy"), gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2.length;i<l;++i) {
    if ( !(gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2[i].isCurrentAnimationName("Hurt")) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2[k] = gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Center"), gdjs.Untitled_32sceneCode.GDCenterObjects2);
/* Reuse gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2[i].getBehavior("BoidsMovement").MoveToObject(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDCenterObjects2Objects, 0.5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2[i].getBehavior("BoidsMovement").AvoidObject(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayerObjects2Objects, 50, 30, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Center"), gdjs.Untitled_32sceneCode.GDCenterObjects2);
gdjs.copyArray(runtimeScene.getObjects("GhostEnemy"), gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("ImpEnemy"), gdjs.Untitled_32sceneCode.GDImpEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("SpiderEnemy"), gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2[i].getX() < (( gdjs.Untitled_32sceneCode.GDCenterObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDCenterObjects2[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2[k] = gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2[i].getX() < (( gdjs.Untitled_32sceneCode.GDCenterObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDCenterObjects2[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2[k] = gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDImpEnemyObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDImpEnemyObjects2[i].getX() < (( gdjs.Untitled_32sceneCode.GDCenterObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDCenterObjects2[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDImpEnemyObjects2[k] = gdjs.Untitled_32sceneCode.GDImpEnemyObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDImpEnemyObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2 */
/* Reuse gdjs.Untitled_32sceneCode.GDImpEnemyObjects2 */
/* Reuse gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2[i].flipX(false);
}
for(var i = 0, len = gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2[i].flipX(false);
}
for(var i = 0, len = gdjs.Untitled_32sceneCode.GDImpEnemyObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDImpEnemyObjects2[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Center"), gdjs.Untitled_32sceneCode.GDCenterObjects2);
gdjs.copyArray(runtimeScene.getObjects("GhostEnemy"), gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("ImpEnemy"), gdjs.Untitled_32sceneCode.GDImpEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("SpiderEnemy"), gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2[i].getX() >= (( gdjs.Untitled_32sceneCode.GDCenterObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDCenterObjects2[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2[k] = gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2[i].getX() >= (( gdjs.Untitled_32sceneCode.GDCenterObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDCenterObjects2[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2[k] = gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDImpEnemyObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDImpEnemyObjects2[i].getX() >= (( gdjs.Untitled_32sceneCode.GDCenterObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDCenterObjects2[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDImpEnemyObjects2[k] = gdjs.Untitled_32sceneCode.GDImpEnemyObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDImpEnemyObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2 */
/* Reuse gdjs.Untitled_32sceneCode.GDImpEnemyObjects2 */
/* Reuse gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2[i].flipX(true);
}
for(var i = 0, len = gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2[i].flipX(true);
}
for(var i = 0, len = gdjs.Untitled_32sceneCode.GDImpEnemyObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDImpEnemyObjects2[i].flipX(true);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("SpawnPoints"), gdjs.Untitled_32sceneCode.GDSpawnPointsObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Enemy Spawn") > 3 / gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickRandomObject((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDSpawnPointsObjects2Objects);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Untitled_32sceneCode.eventsList5(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("GhostEnemy"), gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("ImpEnemy"), gdjs.Untitled_32sceneCode.GDImpEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("SpiderEnemy"), gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2);

gdjs.Untitled_32sceneCode.forEachTotalCount3 = 0;
gdjs.Untitled_32sceneCode.forEachObjects3.length = 0;
gdjs.Untitled_32sceneCode.forEachCount0_3 = gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2.length;
gdjs.Untitled_32sceneCode.forEachTotalCount3 += gdjs.Untitled_32sceneCode.forEachCount0_3;
gdjs.Untitled_32sceneCode.forEachObjects3.push.apply(gdjs.Untitled_32sceneCode.forEachObjects3,gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2);
gdjs.Untitled_32sceneCode.forEachCount1_3 = gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2.length;
gdjs.Untitled_32sceneCode.forEachTotalCount3 += gdjs.Untitled_32sceneCode.forEachCount1_3;
gdjs.Untitled_32sceneCode.forEachObjects3.push.apply(gdjs.Untitled_32sceneCode.forEachObjects3,gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2);
gdjs.Untitled_32sceneCode.forEachCount2_3 = gdjs.Untitled_32sceneCode.GDImpEnemyObjects2.length;
gdjs.Untitled_32sceneCode.forEachTotalCount3 += gdjs.Untitled_32sceneCode.forEachCount2_3;
gdjs.Untitled_32sceneCode.forEachObjects3.push.apply(gdjs.Untitled_32sceneCode.forEachObjects3,gdjs.Untitled_32sceneCode.GDImpEnemyObjects2);
for (gdjs.Untitled_32sceneCode.forEachIndex3 = 0;gdjs.Untitled_32sceneCode.forEachIndex3 < gdjs.Untitled_32sceneCode.forEachTotalCount3;++gdjs.Untitled_32sceneCode.forEachIndex3) {
gdjs.copyArray(runtimeScene.getObjects("HealthBar_Enemy"), gdjs.Untitled_32sceneCode.GDHealthBar_9595EnemyObjects3);
gdjs.Untitled_32sceneCode.GDGhostEnemyObjects3.length = 0;

gdjs.Untitled_32sceneCode.GDImpEnemyObjects3.length = 0;

gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects3.length = 0;


if (gdjs.Untitled_32sceneCode.forEachIndex3 < gdjs.Untitled_32sceneCode.forEachCount0_3) {
    gdjs.Untitled_32sceneCode.GDGhostEnemyObjects3.push(gdjs.Untitled_32sceneCode.forEachObjects3[gdjs.Untitled_32sceneCode.forEachIndex3]);
}
else if (gdjs.Untitled_32sceneCode.forEachIndex3 < gdjs.Untitled_32sceneCode.forEachCount0_3+gdjs.Untitled_32sceneCode.forEachCount1_3) {
    gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects3.push(gdjs.Untitled_32sceneCode.forEachObjects3[gdjs.Untitled_32sceneCode.forEachIndex3]);
}
else if (gdjs.Untitled_32sceneCode.forEachIndex3 < gdjs.Untitled_32sceneCode.forEachCount0_3+gdjs.Untitled_32sceneCode.forEachCount1_3+gdjs.Untitled_32sceneCode.forEachCount2_3) {
    gdjs.Untitled_32sceneCode.GDImpEnemyObjects3.push(gdjs.Untitled_32sceneCode.forEachObjects3[gdjs.Untitled_32sceneCode.forEachIndex3]);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDHealthBar_95959595EnemyObjects3Objects, (gdjs.Untitled_32sceneCode.GDGhostEnemyObjects3.length !== 0 ? gdjs.Untitled_32sceneCode.GDGhostEnemyObjects3[0] : (gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects3.length !== 0 ? gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects3[0] : (gdjs.Untitled_32sceneCode.GDImpEnemyObjects3.length !== 0 ? gdjs.Untitled_32sceneCode.GDImpEnemyObjects3[0] : null))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDHealthBar_9595EnemyObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDHealthBar_9595EnemyObjects3[i].setPosition((( gdjs.Untitled_32sceneCode.GDImpEnemyObjects3.length === 0 ) ? (( gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects3.length === 0 ) ? (( gdjs.Untitled_32sceneCode.GDGhostEnemyObjects3.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDGhostEnemyObjects3[0].getPointX("HealthBar")) :gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects3[0].getPointX("HealthBar")) :gdjs.Untitled_32sceneCode.GDImpEnemyObjects3[0].getPointX("HealthBar")),(( gdjs.Untitled_32sceneCode.GDImpEnemyObjects3.length === 0 ) ? (( gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects3.length === 0 ) ? (( gdjs.Untitled_32sceneCode.GDGhostEnemyObjects3.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDGhostEnemyObjects3[0].getPointY("HealthBar")) :gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects3[0].getPointY("HealthBar")) :gdjs.Untitled_32sceneCode.GDImpEnemyObjects3[0].getPointY("HealthBar")));
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDHealthBar_9595EnemyObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDHealthBar_9595EnemyObjects3[i].setZOrder((( gdjs.Untitled_32sceneCode.GDImpEnemyObjects3.length === 0 ) ? (( gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects3.length === 0 ) ? (( gdjs.Untitled_32sceneCode.GDGhostEnemyObjects3.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDGhostEnemyObjects3[0].getZOrder()) :gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects3[0].getZOrder()) :gdjs.Untitled_32sceneCode.GDImpEnemyObjects3[0].getZOrder()) + 5);
}
}}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Untitled_32sceneCode.GDBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("GhostEnemy"), gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("ImpEnemy"), gdjs.Untitled_32sceneCode.GDImpEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("SpiderEnemy"), gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDBulletObjects2Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDGhostEnemyObjects2ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDSpiderEnemyObjects2ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDImpEnemyObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDBulletObjects2 */
/* Reuse gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2 */
/* Reuse gdjs.Untitled_32sceneCode.GDImpEnemyObjects2 */
/* Reuse gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBulletObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2[i].getBehavior("Health").Hit(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Power")), true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2[i].getBehavior("Health").Hit(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Power")), true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.Untitled_32sceneCode.GDImpEnemyObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDImpEnemyObjects2[i].getBehavior("Health").Hit(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Power")), true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2[i].setAnimationName("Hurt");
}
for(var i = 0, len = gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2[i].setAnimationName("Hurt");
}
for(var i = 0, len = gdjs.Untitled_32sceneCode.GDImpEnemyObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDImpEnemyObjects2[i].setAnimationName("Hurt");
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2[i].setAnimationFrame(0);
}
for(var i = 0, len = gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2[i].setAnimationFrame(0);
}
for(var i = 0, len = gdjs.Untitled_32sceneCode.GDImpEnemyObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDImpEnemyObjects2[i].setAnimationFrame(0);
}
}
{ //Subevents
gdjs.Untitled_32sceneCode.eventsList7(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("GhostEnemy"), gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("ImpEnemy"), gdjs.Untitled_32sceneCode.GDImpEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("SpiderEnemy"), gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2[i].isCurrentAnimationName("Hurt") ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2[k] = gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2[i].isCurrentAnimationName("Hurt") ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2[k] = gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDImpEnemyObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDImpEnemyObjects2[i].isCurrentAnimationName("Hurt") ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDImpEnemyObjects2[k] = gdjs.Untitled_32sceneCode.GDImpEnemyObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDImpEnemyObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2[i].hasAnimationEnded2() ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2[k] = gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2[i].hasAnimationEnded2() ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2[k] = gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDImpEnemyObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDImpEnemyObjects2[i].hasAnimationEnded2() ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDImpEnemyObjects2[k] = gdjs.Untitled_32sceneCode.GDImpEnemyObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDImpEnemyObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2 */
/* Reuse gdjs.Untitled_32sceneCode.GDImpEnemyObjects2 */
/* Reuse gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2[i].setAnimationName("Walking");
}
for(var i = 0, len = gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2[i].setAnimationName("Walking");
}
for(var i = 0, len = gdjs.Untitled_32sceneCode.GDImpEnemyObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDImpEnemyObjects2[i].setAnimationName("Walking");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GhostEnemy"), gdjs.Untitled_32sceneCode.GDGhostEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("ImpEnemy"), gdjs.Untitled_32sceneCode.GDImpEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("SpiderEnemy"), gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDGhostEnemyObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDGhostEnemyObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDGhostEnemyObjects1[k] = gdjs.Untitled_32sceneCode.GDGhostEnemyObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDGhostEnemyObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects1[k] = gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDImpEnemyObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDImpEnemyObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDImpEnemyObjects1[k] = gdjs.Untitled_32sceneCode.GDImpEnemyObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDImpEnemyObjects1.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Untitled_32sceneCode.eventsList8(runtimeScene);} //End of subevents
}

}


};gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDEnemyBulletObjects2Objects = Hashtable.newFrom({"EnemyBullet": gdjs.Untitled_32sceneCode.GDEnemyBulletObjects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Untitled_32sceneCode.GDPlayerObjects2});
gdjs.Untitled_32sceneCode.eventsList10 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__SpriteMultitouchJoystick__IsDirectionPushed4Way.func(runtimeScene, 2, "Secondary", "Left", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.Untitled_32sceneCode.GDGunObjects4);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects4);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayerObjects4[i].flipX(true);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDGunObjects4.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDGunObjects4[i].flipY(true);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__SpriteMultitouchJoystick__IsDirectionPushed4Way.func(runtimeScene, 2, "Secondary", "Right", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.Untitled_32sceneCode.GDGunObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects3);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayerObjects3[i].flipX(false);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDGunObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDGunObjects3[i].flipY(false);
}
}}

}


};gdjs.Untitled_32sceneCode.eventsList11 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDPlayerObjects4.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDPlayerObjects4[i].getX() < gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDPlayerObjects4[k] = gdjs.Untitled_32sceneCode.GDPlayerObjects4[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDPlayerObjects4.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.Untitled_32sceneCode.GDGunObjects4);
/* Reuse gdjs.Untitled_32sceneCode.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayerObjects4[i].flipX(false);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDGunObjects4.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDGunObjects4[i].flipY(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDPlayerObjects3[i].getX() > gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDPlayerObjects3[k] = gdjs.Untitled_32sceneCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.Untitled_32sceneCode.GDGunObjects3);
/* Reuse gdjs.Untitled_32sceneCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayerObjects3[i].flipX(true);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDGunObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDGunObjects3[i].flipY(true);
}
}}

}


};gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.Untitled_32sceneCode.GDBulletObjects3});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.Untitled_32sceneCode.GDBulletObjects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Untitled_32sceneCode.GDPlayerObjects2});
gdjs.Untitled_32sceneCode.eventsList12 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.Untitled_32sceneCode.GDGunObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects3);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDGunObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDGunObjects3[i].setPosition((( gdjs.Untitled_32sceneCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDPlayerObjects3[0].getPointX("Gun")),(( gdjs.Untitled_32sceneCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDPlayerObjects3[0].getPointY("Gun")));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.isMobile());
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.Untitled_32sceneCode.GDGunObjects3);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDGunObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDGunObjects3[i].rotateTowardPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), 0, runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.isMobile();
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.Untitled_32sceneCode.GDGunObjects3);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDGunObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDGunObjects3[i].rotateTowardAngle(gdjs.evtsExt__SpriteMultitouchJoystick__StickAngle.func(runtimeScene, 2, "Secondary", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), 0, runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.isMobile();
if (isConditionTrue_0) {

{ //Subevents
gdjs.Untitled_32sceneCode.eventsList10(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.isMobile());
if (isConditionTrue_0) {

{ //Subevents
gdjs.Untitled_32sceneCode.eventsList11(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_2) {
isConditionTrue_2 = false;
isConditionTrue_2 = !(gdjs.evtTools.systemInfo.isMobile());
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtsExt__SpriteMultitouchJoystick__StickForce.func(runtimeScene, 2, "Secondary", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) > 0;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Untitled_32sceneCode.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.Untitled_32sceneCode.GDGunObjects3);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDGunObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDGunObjects3[i].getBehavior("FireBullet").Fire((gdjs.Untitled_32sceneCode.GDGunObjects3[i].getPointX("BulletPoint")), (gdjs.Untitled_32sceneCode.GDGunObjects3[i].getPointY("BulletPoint")), gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDBulletObjects3Objects, (gdjs.Untitled_32sceneCode.GDGunObjects3[i].getAngle()), 200, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.Untitled_32sceneCode.GDGunObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDGunObjects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDGunObjects3[i].getBehavior("FireBullet").HasJustFired((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDGunObjects3[k] = gdjs.Untitled_32sceneCode.GDGunObjects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDGunObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDGunObjects3 */
{gdjs.evtTools.sound.playSound(runtimeScene, "Gun", false, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Sound")), gdjs.randomFloatInRange(0.8, 1));
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.1, 0, 0.05, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDGunObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDGunObjects3[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 3, 3, 1, 0.05, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Untitled_32sceneCode.GDBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDBulletObjects2Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayerObjects2Objects, 400, true);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDBulletObjects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBulletObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDWallCollisionObjects2Objects = Hashtable.newFrom({"WallCollision": gdjs.Untitled_32sceneCode.GDWallCollisionObjects2});
gdjs.Untitled_32sceneCode.eventsList13 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("WallCollision"), gdjs.Untitled_32sceneCode.GDWallCollisionObjects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayerObjects2[i].separateFromObjectsList(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDWallCollisionObjects2Objects, false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDPlayerObjects2[i].getBehavior("TopDownMovement").isMoving() ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDPlayerObjects2[k] = gdjs.Untitled_32sceneCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayerObjects2[i].setAnimationName("Run");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDPlayerObjects1.length;i<l;++i) {
    if ( !(gdjs.Untitled_32sceneCode.GDPlayerObjects1[i].getBehavior("TopDownMovement").isMoving()) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDPlayerObjects1[k] = gdjs.Untitled_32sceneCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayerObjects1[i].setAnimationName("Idle");
}
}}

}


};gdjs.Untitled_32sceneCode.eventsList14 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("EnemyBullet"), gdjs.Untitled_32sceneCode.GDEnemyBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDEnemyBulletObjects2Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDEnemyBulletObjects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDEnemyBulletObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDEnemyBulletObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{


gdjs.Untitled_32sceneCode.eventsList12(runtimeScene);
}


{


gdjs.Untitled_32sceneCode.eventsList13(runtimeScene);
}


};gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDGhostEnemyObjects2ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDSpiderEnemyObjects2ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDImpEnemyObjects2Objects = Hashtable.newFrom({"GhostEnemy": gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2, "SpiderEnemy": gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2, "ImpEnemy": gdjs.Untitled_32sceneCode.GDImpEnemyObjects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDCenterObjects2Objects = Hashtable.newFrom({"Center": gdjs.Untitled_32sceneCode.GDCenterObjects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDEnemyBulletObjects2Objects = Hashtable.newFrom({"EnemyBullet": gdjs.Untitled_32sceneCode.GDEnemyBulletObjects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDCenterObjects2Objects = Hashtable.newFrom({"Center": gdjs.Untitled_32sceneCode.GDCenterObjects2});
gdjs.Untitled_32sceneCode.eventsList15 = function(runtimeScene) {

{



}


{

gdjs.Untitled_32sceneCode.GDCenterObjects1.length = 0;

gdjs.Untitled_32sceneCode.GDEnemyBulletObjects1.length = 0;

gdjs.Untitled_32sceneCode.GDGhostEnemyObjects1.length = 0;

gdjs.Untitled_32sceneCode.GDImpEnemyObjects1.length = 0;

gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.Untitled_32sceneCode.GDCenterObjects1_1final.length = 0;
gdjs.Untitled_32sceneCode.GDEnemyBulletObjects1_1final.length = 0;
gdjs.Untitled_32sceneCode.GDGhostEnemyObjects1_1final.length = 0;
gdjs.Untitled_32sceneCode.GDImpEnemyObjects1_1final.length = 0;
gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Center"), gdjs.Untitled_32sceneCode.GDCenterObjects2);
gdjs.copyArray(runtimeScene.getObjects("GhostEnemy"), gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("ImpEnemy"), gdjs.Untitled_32sceneCode.GDImpEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("SpiderEnemy"), gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDGhostEnemyObjects2ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDSpiderEnemyObjects2ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDImpEnemyObjects2Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDCenterObjects2Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCenterObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCenterObjects1_1final.indexOf(gdjs.Untitled_32sceneCode.GDCenterObjects2[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCenterObjects1_1final.push(gdjs.Untitled_32sceneCode.GDCenterObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDGhostEnemyObjects1_1final.indexOf(gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDGhostEnemyObjects1_1final.push(gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDImpEnemyObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDImpEnemyObjects1_1final.indexOf(gdjs.Untitled_32sceneCode.GDImpEnemyObjects2[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDImpEnemyObjects1_1final.push(gdjs.Untitled_32sceneCode.GDImpEnemyObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects1_1final.indexOf(gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects1_1final.push(gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Center"), gdjs.Untitled_32sceneCode.GDCenterObjects2);
gdjs.copyArray(runtimeScene.getObjects("EnemyBullet"), gdjs.Untitled_32sceneCode.GDEnemyBulletObjects2);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDEnemyBulletObjects2Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDCenterObjects2Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCenterObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCenterObjects1_1final.indexOf(gdjs.Untitled_32sceneCode.GDCenterObjects2[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCenterObjects1_1final.push(gdjs.Untitled_32sceneCode.GDCenterObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDEnemyBulletObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDEnemyBulletObjects1_1final.indexOf(gdjs.Untitled_32sceneCode.GDEnemyBulletObjects2[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDEnemyBulletObjects1_1final.push(gdjs.Untitled_32sceneCode.GDEnemyBulletObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDCenterObjects1_1final, gdjs.Untitled_32sceneCode.GDCenterObjects1);
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDEnemyBulletObjects1_1final, gdjs.Untitled_32sceneCode.GDEnemyBulletObjects1);
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDGhostEnemyObjects1_1final, gdjs.Untitled_32sceneCode.GDGhostEnemyObjects1);
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDImpEnemyObjects1_1final, gdjs.Untitled_32sceneCode.GDImpEnemyObjects1);
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects1_1final, gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects1);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MainMenu", false);
}}

}


};gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDEXP_95959595PointObjects3Objects = Hashtable.newFrom({"EXP_Point": gdjs.Untitled_32sceneCode.GDEXP_9595PointObjects3});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Untitled_32sceneCode.GDPlayerObjects3});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDEXP_95959595PointObjects3Objects = Hashtable.newFrom({"EXP_Point": gdjs.Untitled_32sceneCode.GDEXP_9595PointObjects3});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Untitled_32sceneCode.GDPlayerObjects3});
gdjs.Untitled_32sceneCode.eventsList16 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Darken"), gdjs.Untitled_32sceneCode.GDDarkenObjects3);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDDarkenObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDDarkenObjects3[i].drawRectangle(0, gdjs.evtTools.camera.getCameraBorderTop(runtimeScene, "LevelUp", 0), gdjs.evtTools.camera.getCameraBorderRight(runtimeScene, "LevelUp", 0), gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "LevelUp", 0));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("EXP_Point"), gdjs.Untitled_32sceneCode.GDEXP_9595PointObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDEXP_95959595PointObjects3Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayerObjects3Objects, 50, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDEXP_9595PointObjects3 */
/* Reuse gdjs.Untitled_32sceneCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDEXP_9595PointObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDEXP_9595PointObjects3[i].addForceTowardObject((gdjs.Untitled_32sceneCode.GDPlayerObjects3.length !== 0 ? gdjs.Untitled_32sceneCode.GDPlayerObjects3[0] : null), 100, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("EXP_Point"), gdjs.Untitled_32sceneCode.GDEXP_9595PointObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDEXP_95959595PointObjects3Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayerObjects3Objects, 3, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDEXP_9595PointObjects3 */
gdjs.copyArray(runtimeScene.getObjects("RedFlatBar"), gdjs.Untitled_32sceneCode.GDRedFlatBarObjects3);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDEXP_9595PointObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDEXP_9595PointObjects3[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).getChild("CurrentEXP").add(1);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDRedFlatBarObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDRedFlatBarObjects3[i].SetMaxValue(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("MaxEXP")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDRedFlatBarObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDRedFlatBarObjects3[i].SetValue(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("CurrentEXP")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("CurrentEXP")) >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("MaxEXP"));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("RedFlatBar"), gdjs.Untitled_32sceneCode.GDRedFlatBarObjects2);
{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0);
}{gdjs.evtTools.camera.showLayer(runtimeScene, "LevelUp");
}{runtimeScene.getScene().getVariables().getFromIndex(0).getChild("CurrentEXP").setNumber(0);
}{runtimeScene.getScene().getVariables().getFromIndex(0).getChild("MaxEXP").setNumber(Math.floor(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("MaxEXP")) * 1.5));
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDRedFlatBarObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDRedFlatBarObjects2[i].SetValue(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("CurrentEXP")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDRedFlatBarObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDRedFlatBarObjects2[i].SetMaxValue(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("MaxEXP")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.Untitled_32sceneCode.eventsList17 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Untitled_32sceneCode.GDPowerButtonObjects1, gdjs.Untitled_32sceneCode.GDPowerButtonObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDPowerButtonObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDPowerButtonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDPowerButtonObjects2[k] = gdjs.Untitled_32sceneCode.GDPowerButtonObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDPowerButtonObjects2.length = k;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Power").add(1);
}}

}


{

gdjs.copyArray(gdjs.Untitled_32sceneCode.GDFireRateButtonObjects1, gdjs.Untitled_32sceneCode.GDFireRateButtonObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDFireRateButtonObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDFireRateButtonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDFireRateButtonObjects2[k] = gdjs.Untitled_32sceneCode.GDFireRateButtonObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDFireRateButtonObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.Untitled_32sceneCode.GDGunObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(0).getChild("FireRate").add(1);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDGunObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDGunObjects2[i].getBehavior("FireBullet").SetCooldownOp((gdjs.Untitled_32sceneCode.GDGunObjects2[i].getBehavior("FireBullet").Cooldown((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) * 0.9, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(gdjs.Untitled_32sceneCode.GDAccuracyButtonObjects1, gdjs.Untitled_32sceneCode.GDAccuracyButtonObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDAccuracyButtonObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDAccuracyButtonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDAccuracyButtonObjects2[k] = gdjs.Untitled_32sceneCode.GDAccuracyButtonObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDAccuracyButtonObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.Untitled_32sceneCode.GDGunObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Accuracy").add(1);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDGunObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDGunObjects2[i].getBehavior("FireBullet").SetAngleVarianceOp((gdjs.Untitled_32sceneCode.GDGunObjects2[i].getBehavior("FireBullet").AngleVariance((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) * 0.9, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Stats"), gdjs.Untitled_32sceneCode.GDStatsObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDStatsObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDStatsObjects1[i].setText("Power: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Power"))) + "\nFire Rate: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("FireRate"))) + "\nAccuracy: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Accuracy"))));
}
}}

}


};gdjs.Untitled_32sceneCode.eventsList18 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("AccuracyButton"), gdjs.Untitled_32sceneCode.GDAccuracyButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("FireRateButton"), gdjs.Untitled_32sceneCode.GDFireRateButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("PowerButton"), gdjs.Untitled_32sceneCode.GDPowerButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDPowerButtonObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDPowerButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDPowerButtonObjects1[k] = gdjs.Untitled_32sceneCode.GDPowerButtonObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDPowerButtonObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDFireRateButtonObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDFireRateButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDFireRateButtonObjects1[k] = gdjs.Untitled_32sceneCode.GDFireRateButtonObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDFireRateButtonObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDAccuracyButtonObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDAccuracyButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDAccuracyButtonObjects1[k] = gdjs.Untitled_32sceneCode.GDAccuracyButtonObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDAccuracyButtonObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "LevelUp");
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "LevelUp");
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1);
}
{ //Subevents
gdjs.Untitled_32sceneCode.eventsList17(runtimeScene);} //End of subevents
}

}


};gdjs.Untitled_32sceneCode.eventsList19 = function(runtimeScene) {

{


gdjs.Untitled_32sceneCode.eventsList16(runtimeScene);
}


{


gdjs.Untitled_32sceneCode.eventsList18(runtimeScene);
}


};gdjs.Untitled_32sceneCode.eventsList20 = function(runtimeScene) {

{


gdjs.Untitled_32sceneCode.eventsList1(runtimeScene);
}


{


gdjs.Untitled_32sceneCode.eventsList2(runtimeScene);
}


{


gdjs.Untitled_32sceneCode.eventsList9(runtimeScene);
}


{


gdjs.Untitled_32sceneCode.eventsList14(runtimeScene);
}


{


gdjs.Untitled_32sceneCode.eventsList15(runtimeScene);
}


{


gdjs.Untitled_32sceneCode.eventsList19(runtimeScene);
}


};

gdjs.Untitled_32sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Untitled_32sceneCode.GDFloorObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDFloorObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDFloorObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDFloorObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDFloorObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDPlayerObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDPlayerObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDPlayerObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDPlayerObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDPlayerObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDGunObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDGunObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDGunObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDGunObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDGunObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDBulletObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBulletObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBulletObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDBulletObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDBulletObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDGhostEnemyObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDGhostEnemyObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDGhostEnemyObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDGhostEnemyObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDGhostEnemyObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDSpiderEnemyObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDImpEnemyObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDImpEnemyObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDImpEnemyObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDImpEnemyObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDImpEnemyObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDCenterObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDCenterObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDCenterObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDCenterObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDCenterObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDSpawnPointsObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDSpawnPointsObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDSpawnPointsObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDSpawnPointsObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDSpawnPointsObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDSpiderSpawnPointsObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDSpiderSpawnPointsObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDSpiderSpawnPointsObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDSpiderSpawnPointsObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDSpiderSpawnPointsObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDHealthBar_9595EnemyObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDHealthBar_9595EnemyObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDHealthBar_9595EnemyObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDHealthBar_9595EnemyObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDHealthBar_9595EnemyObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDWallCollisionObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDWallCollisionObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDWallCollisionObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDWallCollisionObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDWallCollisionObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDvignetteObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDvignetteObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDvignetteObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDvignetteObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDvignetteObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDRedFlatBarObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDRedFlatBarObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDRedFlatBarObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDRedFlatBarObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDRedFlatBarObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDEXP_9595PointObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDEXP_9595PointObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDEXP_9595PointObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDEXP_9595PointObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDEXP_9595PointObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDStatsObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDStatsObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDStatsObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDStatsObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDStatsObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDPowerButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDPowerButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDPowerButtonObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDPowerButtonObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDPowerButtonObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDFireRateButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDFireRateButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDFireRateButtonObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDFireRateButtonObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDFireRateButtonObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDAccuracyButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDAccuracyButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDAccuracyButtonObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDAccuracyButtonObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDAccuracyButtonObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDWaveNumberObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDWaveNumberObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDWaveNumberObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDWaveNumberObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDWaveNumberObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDEnemyBulletObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDEnemyBulletObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDEnemyBulletObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDEnemyBulletObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDEnemyBulletObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDShadowObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDShadowObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDShadowObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDShadowObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDShadowObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDDropObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDDropObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDDropObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDDropObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDDropObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDMovementObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDMovementObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDMovementObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDMovementObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDMovementObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDAimingObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDAimingObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDAimingObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDAimingObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDAimingObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDTransitionObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDTransitionObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDTransitionObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDTransitionObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDTransitionObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDDarkenObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDDarkenObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDDarkenObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDDarkenObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDDarkenObjects5.length = 0;

gdjs.Untitled_32sceneCode.eventsList20(runtimeScene);

return;

}

gdjs['Untitled_32sceneCode'] = gdjs.Untitled_32sceneCode;
